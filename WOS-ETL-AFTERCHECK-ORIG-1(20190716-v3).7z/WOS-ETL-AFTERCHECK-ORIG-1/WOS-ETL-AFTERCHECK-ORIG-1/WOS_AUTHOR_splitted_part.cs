﻿namespace WOS_ETL_AFTERCHECK_ORIG_1
{
    internal class WOS_AUTHOR_splitted_part
    {
    }l
}