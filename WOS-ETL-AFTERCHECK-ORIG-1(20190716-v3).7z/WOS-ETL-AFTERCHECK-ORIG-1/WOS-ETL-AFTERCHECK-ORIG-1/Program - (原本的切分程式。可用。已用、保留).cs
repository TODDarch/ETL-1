﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
//using System.Data.Common;
//TODO: 改善工程:remove library not useD
// 5/15～17 列出效能改善工程：？！！＼
// 以後將切分後加入 LIST
// 改成 切分後（有得切分者+沒得切分者 >> 都一起處理！！ 並直接寫入DB！！）

namespace WOS_ETL_AFTERCHECK_ORIG_1
{
    class Program
    {
        #region environment params
        //args[0] = @"DataAnalysisToolsData_2019世大_ESI失效_2008-2018_SCI SSCI A&HCI_190404"; //請先去掉括號
        static string dbName = @"DataAnalysisToolsData_2019世大_ESI失效_2008-2018_SCI SSCI A&HCI_190404";
        static string destDbName = @"WOS_ETF_T1";

        //取消使用 provider
        static string connString = ("Provider=SQLOLEDB;Server=localhost;Database=master;User Id=sa;Password = Pris9630;");
        static string connString2 = ("Server=localhost;Database=master;User Id=sa;Password = Pris9630;");

        static OleDbConnection conn = new OleDbConnection(connString);
        static OleDbCommand command = new OleDbCommand("", conn);
        static SqlConnection conn2 = new SqlConnection(connString2);
        static SqlCommand command2 = new SqlCommand("", conn2);

        //各單元使用自己的 SqlDataReader (NOT oleDataReader!)
        //SqlDataReader reader_WOS_KEYWORD_AUTHORreader;
        //OleDbDataReader reader;//ToDO: SqlDataReader |OleDbDataReader

        #endregion
        static void Main(string[] args)
        {
            if (args.Length < 2)//(false)//
            {
                Console.WriteLine(@"請輸入來源資料庫全稱:");
                dbName = Console.ReadLine();

                //Console.WriteLine(@"請輸入[轉檔目的地]資料庫全稱:");
                //destDbName = Console.ReadLine();
                //change above into:
                destDbName = string.Format("DTL_{0}", dbName); //[轉檔目的地]資料庫全稱

                Console.WriteLine($"來源資料庫:{dbName}");
                Console.WriteLine($"轉檔資料庫:{destDbName}");
            }
            else
            {

            }




            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            #region WOS_PAPER_TYPE
            List<WOS_PAPER_TYPE> WOS_PAPER_TYPElist = new List<WOS_PAPER_TYPE>();

            string queryString = string.Format(" SELECT OriginIsiId, OriginDocType FROM [{0}].dbo.WosRawData", dbName);

            OleDbDataReader reader = command.ExecuteReader();
            //EXTRACT DATA
            // Always call Read before accessing data.
            while (reader.Read())
            {
                //TODO: stage1: pending modify to stringarray[] 
                //TRAS DATA
                List<string> strList = new List<string>();
                strList = reader.GetString(1).Split(';').ToList();
                for (int i = 0; i < strList.Count(); i++)
                {
                    WOS_PAPER_TYPElist.Add(new WOS_PAPER_TYPE { ISI_ID = reader.GetString(0), Type = strList[i] });
                }
            }

            //REMOVE TABLE
            queryString = @"if object_id (N'WOS_ETF_T1.dbo.WOS_PAPER_TYPE', N'U') IS NOT NULL drop table[WOS_ETF_T1].dbo.WOS_PAPER_TYPE";
            command.CommandText = queryString;
            command.ExecuteNonQuery();

            //LOAD DATA
            foreach (var item in WOS_PAPER_TYPElist)
            {
                queryString = string.Format("insert into [WOS_ETF_T1].dbo.WOS_PAPER_TYPE VALUES( '{0}','{1}' )", item.ISI_ID, (item.Type).Trim());
                command.CommandText = queryString;
                command.ExecuteNonQuery();
            }

            reader.Close();
            conn.Close();
            #endregion
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            #region WOS_KEYWORD_AUTHOR
            //////List<WOS_KEYWORD_AUTHOR> WOS_KEYWORD_AUTHORlist = new List<WOS_KEYWORD_AUTHOR>();

            //////conn.Open();

            ////////REMOVE EXISTING TABLE
            //////string command_WOS_KEYWORD_AUTHOR = @"IF OBJECT_ID (N'WOS_ETF_T1.dbo.WOS_KEYWORD_AUTHOR_splitted_part', N'U') IS NOT NULL DROP TABLE [WOS_ETF_T1].dbo.[WOS_KEYWORD_AUTHOR_splitted_part]";   
            //////command.CommandText = command_WOS_KEYWORD_AUTHOR;
            //////command.ExecuteNonQuery();

            ////////CREATE (TEMP & REAL)TABLE FIRST
            //////command_WOS_KEYWORD_AUTHOR = $"select [WosRawData].[OriginIsiId] AS [ISI_ID], '000' AS[SEQNO], [WosRawData].[AuthorsKeyword]as[Keyword] INTO [WOS_ETF_T1].dbo.[WOS_KEYWORD_AUTHOR_splitted_part] FROM [{dbName}].dbo.WosRawData WHERE 1=0";
            //////command.CommandText = command_WOS_KEYWORD_AUTHOR;
            //////OleDbDataReader reader_WOS_KEYWORD_AUTHOR = command.ExecuteReader();
            //////reader_WOS_KEYWORD_AUTHOR.Close();

            ////////EXTRACT DATA
            //////command_WOS_KEYWORD_AUTHOR = $"select [OriginIsiId], [AuthorsKeyword] FROM [{dbName}].dbo.WosRawData"; //先沒有下 where 條件。1.沒有跨網路（傳輸)2、既然沒有跨網路 多where scan多一次...
            ////////TODO: TOO MUCH DATA IN  JUST ONE SELECT!!! >> 可能要將下一動整併進來！
            ////////TODO: 這裡可能要BCP 或類似觀念的批次轉、
            //////command.CommandText = command_WOS_KEYWORD_AUTHOR;
            //////reader_WOS_KEYWORD_AUTHOR = command.ExecuteReader();
            //////while (reader_WOS_KEYWORD_AUTHOR.Read() ) //增加判斷( like '%;%' )here！！ 應該最快的位置了........(or the next row position, good pplace to determine..)
            //////{
            //////    //TODO: stage1: pending modify to stringarray[]

            //////    //TRAS DATA:
            //////    //如果有切出資料則進行 insert
            //////    if (reader_WOS_KEYWORD_AUTHOR.GetString(1).Contains(";"))
            //////    {
            //////        List<string> typeList = new List<string>();
            //////        typeList = reader_WOS_KEYWORD_AUTHOR.GetString(1).Split(';').ToList();
            //////        for (int i = 0; i < typeList.Count(); i++)
            //////        {
            //////            WOS_KEYWORD_AUTHORlist.Add(new WOS_KEYWORD_AUTHOR { ISI_ID = reader_WOS_KEYWORD_AUTHOR.GetString(0), Keyword = (typeList[i]).Trim(), SEQNO = (i + 1).ToString() });
            //////        }
            //////    }
            //////    //沒有切分出資料
            //////    else
            //////    {
            //////        //THEN DONT ADD TO LIST (WOS_KEYWORD_AUTHORlist)
            //////        continue;
            //////    }

            //////    //TODO:THIS WE CAN PUT INSERT HERE>> 可能要將下一動整併進來
            //////}
            //////reader_WOS_KEYWORD_AUTHOR.Close();

            //////conn2.Open();
            ////////LOAD DATA(WOS_KEYWORD_AUTHOR_splitted_part (temp table))
            //////foreach (var item in WOS_KEYWORD_AUTHORlist)
            //////{
            //////    #region DIRECTLY WRITE TO DEST. TABLE!(suspended)
            //////    //command.CommandText = $"INSERT into [WOS_ETF_T1].dbo.WOS_KEYWORD_AUTHOR VALUES( '{item.ISI_ID}','{item.SEQNO}','{item.Keyword}' )"; 
            //////    #endregion
            //////    #region WRITE TO TEMP TABL(using)
            //////    command.CommandText = $" INSERT into WOS_ETF_T1.dbo.WOS_KEYWORD_AUTHOR_splitted_part VALUES( '{item.ISI_ID}','{item.SEQNO}', @keyword )";//'{item.Keyword}'
            //////    //command.Parameters.Add("keyword", SqlDbType.VarChar).Value = item.Keyword;
            //////    #endregion
            //////    command2 = new SqlCommand(command.CommandText, conn2);
            //////    command2.Parameters.Add(new SqlParameter() { ParameterName = "keyword", Value = item.Keyword });
            //////    command2.ExecuteNonQuery();//command.ExecuteNonQuery();
            //////}
            //////conn.Close();
            //////conn2.Close();

            #endregion
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            #region WOS_AUTHOR 作者 0517-1700 //此段程式碼最特別不能複製共用｜無通用
            List<WOS_AUTHOR_splitted_part_pk> WOS_AUTHORlist = new List<WOS_AUTHOR_splitted_part_pk>();

            //REMOVE EXISTING TABLE
            string command_WOS_AUTHOR = @"IF OBJECT_ID (N'WOS_ETF_T1.dbo.WOS_AUTHOR_splitted_part_pk', N'U') IS NOT NULL DROP TABLE [WOS_ETF_T1].dbo.[WOS_AUTHOR_splitted_part_pk]";
            command.CommandText = command_WOS_AUTHOR;
            conn.Open();
            command.ExecuteNonQuery();


            //CREATE (TEMP & REAL)TABLE FIRST
            command_WOS_AUTHOR = $@"select 
	                     m.IsiId 
	                    ,0 AS SEQNO
	                    ,m.[OriginIsiId] AS [ISI_ID]
	                    ,m.[ResearcherID] as [ResearcherID]
	                    ,m.[OrcId] [OrcId] 
	                    ,p.FullName
	                    INTO [WOS_ETF_T1].dbo.[WOS_AUTHOR_splitted_part_pk] 
	                    FROM [{dbName}].dbo.WosRawData m 
	                    LEFT JOIN [{dbName}].dbo.[Author] p on m.IsiId = p.IsiId 
	                    WHERE 1=0";

            //TODO:... from wosraw?

            command.CommandText = command_WOS_AUTHOR;
            OleDbDataReader reader = command.ExecuteReader();
            reader.Close();

            //EXTRACT DATA
            command_WOS_AUTHOR = $"select m.[OriginIsiId] AS [ISI_ID], m.[ResearcherID] [ResearcherID], m.[OrcId] [OrcId],m.IsiId, FROM [{dbName}].dbo.WosRawData m WHERE (m.OrcId like '%;%' OR m.ResearcherID like '%;%') ";//TODO:... from wosraw?
            command.CommandText = command_WOS_AUTHOR;
            reader = command.ExecuteReader();
            while (reader.Read())
            {
                //TRAS DATA:
                //如果有切出資料則進行 insert >> 移動至 SQLCMD WHERE 篩選
                if (true)//if (reader.GetString(2).Contains(";"))
                {
                    List<string> typeList2 = reader.GetString(2).Split(';').ToList();//orcid
                    List<string> typeList = reader.GetString(2).Split(';').ToList();//ResearcherID
                    for (int i = 0; i < typeList2.Count(); i++)
                    {
                        WOS_AUTHORlist.Add(new WOS_AUTHOR_splitted_part_pk { ISI_ID = reader.GetString(0), ResearcherID = (((i + 1) <= typeList.Count()) ? typeList[i] : "").Trim(), OrcId = (typeList2[i]), IsiId = reader.GetInt64(3),SEQNO = i+1,FullName =  });
                    }
                }
                //沒有切分出資料
                else
                {
                    continue;
                }
            }
            reader.Close();

            conn2.Open();
            //LOAD DATA(WOS_AUTHOR_splitted_part_pk (temp table))
            foreach (var item in WOS_AUTHORlist)
            {
                //WRITE TO TEMP TABLE
                command.CommandText = $" INSERT into [WOS_ETF_T1].dbo.WOS_AUTHOR_splitted_part_pk VALUES( '{item.IsiId}',{????},'{item.ISI_ID}', @ResearcherID, @OrcId )";//'{item.Keyword}'
                command2 = new SqlCommand(command.CommandText, conn2);
                //command2.Parameters.Add(new SqlParameter() { ParameterName = "@Name", Value = item.Name });
                command2.Parameters.Add(new SqlParameter() { ParameterName = "@ResearcherID", Value = item.ResearcherID });
                command2.Parameters.Add(new SqlParameter() { ParameterName = "@OrcId", Value = item.OrcId });
                command2.ExecuteNonQuery();
            }
            conn.Close();
            conn2.Close();
            #endregion
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            #region WOS_KEYWORD_WOS 
            //////List<WOS_KEYWORD_WOS> WOS_KEYWORD_WOSlist = new List<WOS_KEYWORD_WOS>();

            //////conn.Open();

            ////////REMOVE EXISTING TABLE
            //////string command_WOS_KEYWORD_WOS = @"IF OBJECT_ID (N'WOS_ETF_T1.dbo.WOS_KEYWORD_WOS', N'U') IS NOT NULL DROP TABLE [WOS_ETF_T1].dbo.[WOS_KEYWORD_WOS]";
            //////command.CommandText = command_WOS_KEYWORD_WOS;
            //////command.ExecuteNonQuery();

            ////////CREATE TABLE FIRST
            //////command_WOS_KEYWORD_WOS = $"select [WosRawData].[OriginIsiId] AS [ISI_ID], '000' AS[SEQNO], [WosRawData].[AuthorsKeyword]as[Keyword] INTO [WOS_ETF_T1].dbo.[WOS_KEYWORD_WOS] FROM [{dbName}].dbo.WosRawData WHERE 1=0";
            //////command.CommandText = command_WOS_KEYWORD_WOS;
            //////OleDbDataReader reader_WOS_KEYWORD_WOS = command.ExecuteReader();
            //////reader_WOS_KEYWORD_WOS.Close();

            ////////EXTRACT DATA
            //////command_WOS_KEYWORD_WOS = $"select [OriginIsiId], [Keyword] FROM [{dbName}].dbo.WosRawData";
            //////command.CommandText = command_WOS_KEYWORD_WOS;
            //////reader_WOS_KEYWORD_WOS = command.ExecuteReader();
            //////while (reader_WOS_KEYWORD_WOS.Read())
            //////{
            //////    //TRAS DATA:
            //////    //如果有切出資料則進行 insert
            //////    if (reader_WOS_KEYWORD_WOS.GetString(1).Contains(";"))
            //////    {
            //////        List<string> typeList = new List<string>();
            //////        typeList = reader_WOS_KEYWORD_WOS.GetString(1).Split(';').ToList();
            //////        for (int i = 0; i < typeList.Count(); i++)
            //////        {
            //////            WOS_KEYWORD_WOSlist.Add(new WOS_KEYWORD_WOS { ISI_ID = reader_WOS_KEYWORD_WOS.GetString(0), Keyword = (typeList[i]).Trim(), SEQNO = (i + 1).ToString() });
            //////        }
            //////    }
            //////    //沒有切分出資料
            //////    else
            //////    {
            //////        WOS_KEYWORD_WOSlist.Add(new WOS_KEYWORD_WOS { ISI_ID = reader_WOS_KEYWORD_WOS.GetString(0), Keyword = reader_WOS_KEYWORD_WOS.GetString(1), SEQNO = "1" });
            //////    }
            //////}
            //////reader_WOS_KEYWORD_WOS.Close();

            //////conn2.Open();
            ////////LOAD DATA
            //////foreach (var item in WOS_KEYWORD_WOSlist)
            //////{
            //////    //WRITE TO TABLE
            //////    command.CommandText = $" INSERT into [WOS_ETF_T1].dbo.WOS_KEYWORD_WOS VALUES( '{item.ISI_ID}','{item.SEQNO}', @keyword )";
            //////    command2 = new SqlCommand(command.CommandText, conn2);
            //////    command2.Parameters.Add(new SqlParameter() { ParameterName = "keyword", Value = item.Keyword });
            //////    command2.ExecuteNonQuery();
            //////}
            //////conn.Close();
            //////conn2.Close();
            #endregion
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            #region WOS_CATEGORY_SUBJECT
            List<WOS_CATEGORY_SUBJECT_splitted_part> WOS_CATEGORY_SUBJECTlist = new List<WOS_CATEGORY_SUBJECT_splitted_part>();

            conn.Open();

            //REMOVE EXISTING TABLE
            string command_WOS_CATEGORY_SUBJECT = @"IF OBJECT_ID (N'WOS_ETF_T1.dbo.WOS_CATEGORY_SUBJECT_splitted_part', N'U') IS NOT NULL DROP TABLE [WOS_ETF_T1].dbo.[WOS_CATEGORY_SUBJECT_splitted_part]";
            command.CommandText = command_WOS_CATEGORY_SUBJECT;
            command.ExecuteNonQuery();

            //CREATE (TEMP & REAL)TABLE FIRST
            command_WOS_CATEGORY_SUBJECT = $"select [WosRawData].[OriginIsiId] AS [ISI_ID], '000' AS[SEQNO], [WosRawData].[SubjectAreas]as[Category] INTO [WOS_ETF_T1].dbo.[WOS_CATEGORY_SUBJECT_splitted_part] FROM [{dbName}].dbo.WosRawData WHERE 1=0";
            command.CommandText = command_WOS_CATEGORY_SUBJECT;
            OleDbDataReader reader_WOS_CATEGORY_SUBJECT = command.ExecuteReader();
            reader_WOS_CATEGORY_SUBJECT.Close();

            //EXTRACT DATA
            command_WOS_CATEGORY_SUBJECT = $"select [OriginIsiId], [SubjectAreas] FROM [{dbName}].dbo.WosRawData"; //先沒有下 where 條件。1.沒有跨網路（傳輸)2、既然沒有跨網路 多where scan多一次...
            //TODO: TOO MUCH DATA IN  JUST ONE SELECT!!! >> 可能要將下一動整併進來！
            //TODO: 這裡可能要BCP 或類似觀念的批次轉、
            command.CommandText = command_WOS_CATEGORY_SUBJECT;
            reader_WOS_CATEGORY_SUBJECT = command.ExecuteReader();
            while (reader_WOS_CATEGORY_SUBJECT.Read()) //增加判斷( like '%;%' )here！！ 應該最快的位置了........(or the next row position, good pplace to determine..)
            {
                //TODO: stage1: pending modify to stringarray[]

                //TRAS DATA:
                //如果有切出資料則進行 insert
                if (reader_WOS_CATEGORY_SUBJECT.GetString(1).Contains(";"))
                {
                    List<string> typeList = new List<string>();
                    typeList = reader_WOS_CATEGORY_SUBJECT.GetString(1).Split(';').ToList();
                    for (int i = 0; i < typeList.Count(); i++)
                    {
                        WOS_CATEGORY_SUBJECTlist.Add(new WOS_CATEGORY_SUBJECT_splitted_part { ISI_ID = reader_WOS_CATEGORY_SUBJECT.GetString(0), Category = (typeList[i]).Trim() });
                    }
                }
                //沒有切分出資料
                else
                {
                    //THEN DONT ADD TO LIST (WOS_CATEGORY_SUBJECTlist)
                    continue;
                }

                //TODO:THIS WE CAN PUT INSERT HERE>> 可能要將下一動整併進來
            }
            reader_WOS_CATEGORY_SUBJECT.Close();

            conn2.Open();
            //LOAD DATA(WOS_CATEGORY_SUBJECT_splitted_part (temp table))
            foreach (var item in WOS_CATEGORY_SUBJECTlist)
            {
                #region DIRECTLY WRITE TO DEST. TABLE!(suspended)
                //command.CommandText = $"INSERT into [WOS_ETF_T1].dbo.WOS_CATEGORY_SUBJECT VALUES( '{item.ISI_ID}','','{item.Category}' )"; 
                #endregion
                #region WRITE TO TEMP TABL(using)
                command.CommandText = $" INSERT into WOS_ETF_T1.dbo.WOS_CATEGORY_SUBJECT_splitted_part VALUES( '{item.ISI_ID}','', @Category)";//'{item.Category}'
                //command.Parameters.Add("Category", SqlDbType.VarChar).Value = item.Category;
                #endregion
                command2 = new SqlCommand(command.CommandText, conn2);
                command2.Parameters.Add(new SqlParameter() { ParameterName = "@Category", Value = item.Category });
                command2.ExecuteNonQuery();//command.ExecuteNonQuery();
            }
            conn.Close();
            conn2.Close();

            #endregion
        }


        class WOS_PAPER_TYPE
        {
            public string ISI_ID { get; set; }
            public string Type { get; set; }
        }

        class WOS_KEYWORD_AUTHOR
        {
            public string ISI_ID { get; set; }
            public string SEQNO { get; set; }
            public string Keyword { get; set; }

        }

        class WOS_KEYWORD_WOS
        {
            public string ISI_ID { get; set; }
            public string SEQNO { get; set; }
            public string Keyword { get; set; }

        }

        //WOS_AUTHOR_切

        class WOS_AUTHOR_splitted_part_pk
        {
            public Int64 IsiId { get; set; }
            public Int64 SEQNO { get; set; }

            public string ISI_ID { get; set; }
            public string ResearcherID { get; set; }
            public string OrcId { get; set; }
            public string FullName { get; set; }
        }

        //WOS_CATEGORY_SUBJECT





        class WOS_CATEGORY_SUBJECT_splitted_part
        {
            public string ISI_ID { get; set; }
            public string SEQNO { get; set; }
            public string Category { get; set; }
        }
    }
}
