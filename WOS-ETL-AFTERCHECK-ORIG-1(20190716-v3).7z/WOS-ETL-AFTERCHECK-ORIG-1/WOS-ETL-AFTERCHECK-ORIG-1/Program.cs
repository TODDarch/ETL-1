﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Diagnostics;

using System.IO;

//using System.Data.Common;
//TODO: 改善工程:remove library not useD
// 5/15～17 列出效能改善工程：？！！
// 以後將切分後加入 LIST
// 改成 切分後（有得切分者+沒得切分者 >> 都一起處理！！ 並直接寫入DB！！）

namespace WOS_ETL_AFTERCHECK_ORIG_1
{

    public class Program
    {
        #region environment params

        //PREFIX:
        static string prefix = "PRIS_WOS";

        //return code
        static int exitCode = 0;
        #endregion

        public static void Main(string[] args)
        {
#if xx

#endif
            args = new string[] {"localhost","sa", "Pris9630", "DataAnalysisToolsData_2018_巨量_高被引論文_2018-2018_SCI SSCI A&HCI_190530", "localhost","sa","Pris9630" };

            #region parameters
            //LOGGING SQL COMMAND
            string loggingCmd = string.Format("exec ETL_BASE_1.dbo.SP_ERR_LOGGING_V1 '{0}','  ALL','TEDYEh','msg',''",DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss.fff"));

            //args[0] = @"DataAnalysisToolsData_2019世大_ESI失效_2008-2018_SCI SSCI A&HCI_190404"; //請先去掉括號
            string sourceIP = args[0];
            string srcU = args[1];
            string srcP = args[2];
            string srcDbName = args[3];//eg:@"DataAnalysisToolsData_2019世大_ESI失效_2008-2018_SCI SSCI A&HCI_190404";
            string destIP = "localhost";//args[4];//LOCAL轉檔 
            string destU = "sa";//args[5];
            string destP = "Pris9630";//args[6];
            string destDbName = string.Format(srcDbName.Replace("DataAnalysisToolsData", prefix));

            //取消使用 provider  //string connString = string.Format("Provider=SQLOLEDB;Server=localhost;Database=master;User Id=LIS_User;Password = Pris9630;");
            string srcConnStr = string.Format("Server={0};Database=ETL_BASE_1;User Id={1};Password ={2};", sourceIP,srcU,srcP);
            string destConnStr = string.Format("Server={0};Database=ETL_BASE_1;User Id={1};Password ={2};", destIP, destU, destP);

            //原用
            //static OleDbConnection conn = new OleDbConnection(connString);
            //static OleDbCommand command = new OleDbCommand("", conn);
            //改用:
            SqlConnection srcConn = new SqlConnection();
            SqlConnection destConn = new SqlConnection();
            SqlCommand sqlcmd = new SqlCommand();

            //各單元使用自己的 SqlDataReader (NOT oleDataReader!)
            //SqlDataReader reader_WOS_KEYWORD_AUTHORreader;
            //OleDbDataReader reader;//ToDO: SqlDataReader |OleDbDataReader

            //
            string sqlcmdFilePath_OriVer = @"C:\ws\ms\轉檔包-1\etl_rkng_20190715.SQL";
            string sqlcmdFilePath_exeVer = @"C:\ws\ms\轉檔包-1\etl_rkng_20190715_EXE.SQL";
            string sqlcmdFilePath_OriVer_step2 = @"C:\ws\ms\轉檔包-1\etl_rkng_20190715_rmv_null.SQL";
            string sqlcmdFilePath_exeVer_step2 = @"C:\ws\ms\轉檔包-1\etl_rkng_20190715_rmv_null_EXE.SQL";
            string sqlcmdFilePath_OriVer_step3 = @"C:\ws\ms\轉檔包-1\etl_rkng_20190715-AC-control.SQL";
            string sqlcmdFilePath_exeVer_step3 = @"C:\ws\ms\轉檔包-1\etl_rkng_20190715-AC-control_EXE.SQL";
            #endregion

            //START

            if (args.Length == 0)
            return;
            else
                try
                {
                    //1.process execute sqlcmd create database with prefix
                    string step1 = "create database [" + destDbName + "]";
                    destConn.ConnectionString = destConnStr;
                    destConn.Open();

                    //reF://SqlCommand sqlcmd = new SqlCommand("", srcConn);
                    sqlcmd.CommandText = step1;
                    sqlcmd.Connection = destConn;
                    sqlcmd.ExecuteNonQuery();
                    destConn.Close();
                    #region EXECUTE SQLCOMMAND(SQL)

                    //DELETE DESTINATION FILE
                    if (File.Exists(sqlcmdFilePath_exeVer))
                        File.Delete(sqlcmdFilePath_exeVer);

                    //DELETE DESTINATION FILE
                    if (File.Exists(sqlcmdFilePath_exeVer_step2))
                        File.Delete(sqlcmdFilePath_exeVer_step2);
                    //DELETE DESTINATION FILE
                    if (File.Exists(sqlcmdFilePath_exeVer_step3))
                        File.Delete(sqlcmdFilePath_exeVer_step3);

                    string cmdline = string.Empty;
                    using (StreamReader sr = new StreamReader(sqlcmdFilePath_OriVer, Encoding.Unicode))
                    {
                        while(sr.Peek()>=0)
                        using (StreamWriter outputFile = new StreamWriter(sqlcmdFilePath_exeVer, true,Encoding.Unicode))
                        {
                            cmdline = sr.ReadLine();
                                cmdline = cmdline.Replace("DESTDATABASE", destDbName);
                                //cmdline = cmdline.Replace("destIP", destIP); //請改由畚箕轉檔
                                cmdline = cmdline.Replace("SRCDATABASE", srcDbName);
                                //cmdline = cmdline.Replace("sourceIP", sourceIP); //請改由畚箕轉檔

                                //寫入執行版本SQL:
                                //foreach (string line in lines)
                                //    outputFile.WriteLine(line);
                                outputFile.WriteLine(cmdline);

                                // Read the stream to a string, and write the string to the console.
                                //String line = sr.ReadToEnd();
                                //Console.WriteLine(line);
                        }

                    }

                    //EXECUTE MODed SQL FILE
                    string cmd = $@"sqlcmd -i {sqlcmdFilePath_exeVer} -o C:\ws\ms\sql-t1-out.json -u -X -x -S localhost -d master -U {destU} -P {destP}";
                    //THIS WORKS:cmd = $@"sqlcmd -q'backup database ETL_BASE_1 to disk = N'S:\ETL_BASE_1.BAK' with format' -o C:\ws\ms\sql-t1-out.json -u -X -x -S localhost -d master -U sa -P Pris9630";
                    //THIS WORKS:cmd = $@"schtasks /create /tn OpenNotepad{DateTime.Now:HHmmss} /tr code /sc ONCE /st 11:20:00";// @"C:\Doit.bat";
                    ////cmd = $@"sqlcmd -q'backup database ETL_BASE_1 to disk = N'S:\ETL_BASE_1.BAK' with format' -o C:\ws\ms\sql-t1-out.json -u -X -x -S localhost -d master -U sa -P Pris9630";
                    ////C:\ws\ms\sql-t2.sql
                    //Thread.Sleep(1000);//TO MAKE THE "SECOND" PART NOT DUPLICATED
                    string command = cmd;

                    //BUILD AN RUN PROCESS//START
                    ProcessStartInfo processInfo;
                    Process process;
                    processInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
                    processInfo.CreateNoWindow = true;
                    processInfo.UseShellExecute = false;
                    processInfo.RedirectStandardError = true;
                    processInfo.RedirectStandardOutput = true;

                    process = Process.Start(processInfo);//process.WaitForExit();

                    #region OUTPUT HANDLE 2
                    process.OutputDataReceived += (object sender, DataReceivedEventArgs e) =>
                        Console.WriteLine("output>>" + e.Data);
                    process.BeginOutputReadLine();

                    process.ErrorDataReceived += (object sender, DataReceivedEventArgs e) =>
                        Console.WriteLine("error>>" + e.Data);
                    process.BeginErrorReadLine();

                    process.WaitForExit();
                    process.Close();
                    #endregion OUTPUT HANDLE 2
                    #endregion


                    //2.REPLACE database name in the .sql file...DATABASENAME
                    //3.process call sp_ in etl base >> done


                    //step2
                    string cmdline_step2 = string.Empty;
                    using (StreamReader sr = new StreamReader(sqlcmdFilePath_OriVer_step2, Encoding.ASCII))
                    {
                        while (sr.Peek() >= 0)
                            using (StreamWriter outputFile = new StreamWriter(sqlcmdFilePath_exeVer_step2, true, Encoding.Unicode))
                            {
                                cmdline_step2 = sr.ReadLine();
                                cmdline_step2 = cmdline_step2.Replace("DESTDATABASE", destDbName);
                                //cmdline_step2 = cmdline_step2.Replace("destIP", destIP); //請改由畚箕轉檔

                                //cmdline_step2 = cmdline_step2.Replace("sourceIP", sourceIP); //請改由畚箕轉檔

                                //WRITE 2 FILE
                                outputFile.WriteLine(cmdline_step2);
                            }
                    }
                    cmd = $@"sqlcmd -i {sqlcmdFilePath_exeVer_step2} -o C:\ws\ms\sql-t1-out2.json -u -X -x -S localhost -d master -U {destU} -P {destP}";
                    //THIS WORKS:cmd = $@"sqlcmd -q'backup database ETL_BASE_1 to disk = N'S:\ETL_BASE_1.BAK' with format' -o C:\ws\ms\sql-t1-out.json -u -X -x -S localhost -d master -U sa -P Pris9630";
                    //THIS WORKS:cmd = $@"schtasks /create /tn OpenNotepad{DateTime.Now:HHmmss} /tr code /sc ONCE /st 11:20:00";// @"C:\Doit.bat";
                    ////cmd = $@"sqlcmd -q'backup database ETL_BASE_1 to disk = N'S:\ETL_BASE_1.BAK' with format' -o C:\ws\ms\sql-t1-out.json -u -X -x -S localhost -d master -U sa -P Pris9630";
                    ////C:\ws\ms\sql-t2.sql
                    //Thread.Sleep(1000);//TO MAKE THE "SECOND" PART NOT DUPLICATED
                    command = cmd;

                    //BUILD AN RUN PROCESS//START
                    //ProcessStartInfo processInfo;
                    process = new Process();//Process process;
                    processInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
                    processInfo.CreateNoWindow = true;
                    processInfo.UseShellExecute = false;
                    processInfo.RedirectStandardError = true;
                    processInfo.RedirectStandardOutput = true;

                    process = Process.Start(processInfo);//process.WaitForExit();

                    #region OUTPUT HANDLE 2
                    process.OutputDataReceived += (object sender, DataReceivedEventArgs e) =>
                        Console.WriteLine("output>>" + e.Data);
                    process.BeginOutputReadLine();

                    process.ErrorDataReceived += (object sender, DataReceivedEventArgs e) =>
                        Console.WriteLine("error>>" + e.Data);
                    process.BeginErrorReadLine();

                    process.WaitForExit();
                    process.Close();
                    #endregion OUTPUT HANDLE 2
                    //step3
                    string cmdline_3 = string.Empty;
                    using (StreamReader sr = new StreamReader(sqlcmdFilePath_OriVer_step3, Encoding.ASCII))
                    {
                        while (sr.Peek() >= 0)
                            using (StreamWriter outputFile = new StreamWriter(sqlcmdFilePath_exeVer_step3, true, Encoding.Unicode))
                            {
                                cmdline_3 = sr.ReadLine();
                                cmdline_3 = cmdline_3.Replace("DESTDATABASE", destDbName);
                                //cmdline = cmdline.Replace("destIP", destIP); //請改由畚箕轉檔
                                cmdline_3 = cmdline_3.Replace("SRCDATABASE", srcDbName);
                                //cmdline = cmdline.Replace("sourceIP", sourceIP); //請改由畚箕轉檔

                                //寫入執行版本SQL:
                                //foreach (string line in lines)
                                //    outputFile.WriteLine(line);
                                outputFile.WriteLine(cmdline_3);

                                // Read the stream to a string, and write the string to the console.
                                //String line = sr.ReadToEnd();
                                //Console.WriteLine(line);
                            }

                    }
                    cmd = $@"sqlcmd -i {sqlcmdFilePath_exeVer_step3} -o C:\ws\ms\sql-t1-out3.json -u -X -x -S localhost -d master -U {destU} -P {destP}";
                    //THIS WORKS:cmd = $@"sqlcmd -q'backup database ETL_BASE_1 to disk = N'S:\ETL_BASE_1.BAK' with format' -o C:\ws\ms\sql-t1-out.json -u -X -x -S localhost -d master -U sa -P Pris9630";
                    //THIS WORKS:cmd = $@"schtasks /create /tn OpenNotepad{DateTime.Now:HHmmss} /tr code /sc ONCE /st 11:20:00";// @"C:\Doit.bat";
                    ////cmd = $@"sqlcmd -q'backup database ETL_BASE_1 to disk = N'S:\ETL_BASE_1.BAK' with format' -o C:\ws\ms\sql-t1-out.json -u -X -x -S localhost -d master -U sa -P Pris9630";
                    ////C:\ws\ms\sql-t2.sql
                    //Thread.Sleep(1000);//TO MAKE THE "SECOND" PART NOT DUPLICATED
                    command = cmd;

                    //BUILD AN RUN PROCESS//START
                    //ProcessStartInfo processInfo;
                    process = new Process();//Process process;
                    processInfo = new ProcessStartInfo("cmd.exe", "/c " + command);
                    processInfo.CreateNoWindow = true;
                    processInfo.UseShellExecute = false;
                    processInfo.RedirectStandardError = true;
                    processInfo.RedirectStandardOutput = true;

                    process = Process.Start(processInfo);//process.WaitForExit();

                    #region OUTPUT HANDLE 2
                    process.OutputDataReceived += (object sender, DataReceivedEventArgs e) =>
                        Console.WriteLine("output>>" + e.Data);
                    process.BeginOutputReadLine();

                    process.ErrorDataReceived += (object sender, DataReceivedEventArgs e) =>
                        Console.WriteLine("error>>" + e.Data);
                    process.BeginErrorReadLine();

                    process.WaitForExit();
                    process.Close();
                    #endregion OUTPUT HANDLE 2



                    return;
                }
                catch (Exception ex)
                {
                    //LOG
                    destConn.Open();
                    sqlcmd.CommandText = loggingCmd.Replace("msg",ex.Message.Replace("'",""));
                    sqlcmd.Connection = destConn;
                    sqlcmd.ExecuteNonQuery();
                    destConn.Close();
                    //throw;
                    return;
                }
            return;//TO END THIS PROGRAM;
            //////////////////////////////////////////////////////////////////////
            string type_ = args[2];
            if (type_ == "1")
                goto ESISX;
            else if (type_ == "2")
                goto ALLSC;
            else if (type_ == "3")
                goto FIELD;
            else if (type_ == "4")
                goto ENGER;
            else
                return;

            ESISX:
            {
                Console.WriteLine("ESISX");
                return;
                string step1 = @"create database " + destDbName; //1(一般)轉檔
                string step2 = @"exec [dbo].[sp_wos_etl_ESISX] "; //2移除空(白)值
                string step3 = @"exec [dbo].[sp_wos_etl_ESISX] "; //3進行權控轉檔


                return;



                return;

                /////////////////////////////////////
                if (true)//(false)//
                {
                    //來源資料庫
                    //Console.WriteLine(@"請輸入來源資料庫IP:");
                    //srcDbName = Console.ReadLine();
                    //USE THIS INSTEAD: //20190710 mod by TED
                    sourceIP = args[0].ToString();

                    //Console.WriteLine(@"請輸入檔來源資料庫全稱:");
                    //srcDbName = Console.ReadLine();
                    //USE THIS INSTEAD:
                    srcDbName = args[1].ToString();

                    //目的地資料庫
                    //Console.WriteLine(@"請輸入目的地資料庫IP:");
                    //destIP = args[3].ToString();
                    //USE THE FOLLOWING INSTEAD FOR AUTO. SETTINGS
                    //destIP = //SET AT THE BEGINNING OF THIS CLASS.

                    //自動搭配來源資料庫名稱，生成新資料庫名稱
                    //Console.WriteLine(@"請輸入[轉檔目的地資料庫]全稱:");
                    destDbName = string.Format("DTL_{0}", srcDbName);

                    //cmd = @"schtasks /create /tn OpenNotepad3 /tr notepad.exe /sc ONCE /st 10:36:55";

                    //Thread newThr = new Thread(ThreadWork.scheT1);

                    //schtasks /create /tn OpenNotepad3 /tr notepad.exe /sc ONCE /st 10:36:55
                }
                else
                {

                }
                /////////////////////////////////////
            }

        ALLSC:
            {
                Console.WriteLine("執行轉檔 ALLSC");
                return;
            }


        FIELD:
            {
                Console.WriteLine("執行轉檔 FIELD");
                return;
            }

        ENGER:
            {
                Console.WriteLine("執行轉檔 ENGER");
                return;
            }
        }
    }
}
